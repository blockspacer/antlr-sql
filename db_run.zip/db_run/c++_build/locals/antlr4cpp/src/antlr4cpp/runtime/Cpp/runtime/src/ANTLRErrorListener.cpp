#include "ANTLRErrorListener.h"

antlr4::ANTLRErrorListener::~ANTLRErrorListener()
{
}
