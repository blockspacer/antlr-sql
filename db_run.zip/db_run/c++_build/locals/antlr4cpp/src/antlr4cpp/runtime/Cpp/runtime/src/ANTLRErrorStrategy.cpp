#include "ANTLRErrorStrategy.h"

antlr4::ANTLRErrorStrategy::~ANTLRErrorStrategy()
{
}
