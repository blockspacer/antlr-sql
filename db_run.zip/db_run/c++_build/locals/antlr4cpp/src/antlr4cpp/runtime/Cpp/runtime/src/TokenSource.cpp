#include "TokenSource.h"

antlr4::TokenSource::~TokenSource() {
}
