#include "Token.h"

antlr4::Token::~Token() {
}
